package br.com.serasa.page;

import br.com.serasa.core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class NavigationPage extends BasePage {

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/header[1]/div[1]/div[2]/div[1]/div[1]/button[1]")
    private WebElement oque_voce_precisa_button;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/header[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/a[1]")
    private WebElement submenu_ecred;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/header[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/a[2]")
    private WebElement submenu_premiun;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/header[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/a[3]")
    private WebElement submenu_limpa_nome;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[2]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/a[1]/button[1]")
    private WebElement ecred_simule_gratis_button;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/main[1]/section[1]/div[1]/div[1]/a[1]")
    private WebElement premium_conheca_nossos_planos_button;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[3]/div[1]/a[1]")
    private WebElement consultar_cpf_button;

    public NavigationPage(RemoteWebDriver driver) {
        super(driver);
    }

    public NavigationPage homeConsultarCpfButton() {
        waitForElement(consultar_cpf_button);
        this.consultar_cpf_button.click();
        return this;
    }

    public NavigationPage clickPremiumConhecaNossosPlanos() {
        waitForElement(premium_conheca_nossos_planos_button);
        this.premium_conheca_nossos_planos_button.click();
        return this;
    }

    public NavigationPage clickEcredSimuleGratis() {
        waitForElement(ecred_simule_gratis_button);
        this.ecred_simule_gratis_button.click();
        return this;
    }

    public NavigationPage clickSubMenuLimpaNome() {
        waitForElement(submenu_limpa_nome);
        this.submenu_limpa_nome.click();
        return this;
    }

    public NavigationPage clickSubMenuPremium() {
        waitForElement(submenu_premiun);
        this.submenu_premiun.click();
        return this;
    }

    public NavigationPage clickSubMenuEcred() {
        waitForElement(submenu_ecred);
        this.submenu_ecred.click();
        return this;
    }

    public NavigationPage clickOqueVocePrecisaButton() {
        waitForElement(oque_voce_precisa_button);
        this.oque_voce_precisa_button.click();
        return this;
    }

}