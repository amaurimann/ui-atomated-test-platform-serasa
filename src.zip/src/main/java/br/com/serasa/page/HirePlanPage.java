package br.com.serasa.page;

import br.com.serasa.core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class HirePlanPage extends BasePage {

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-choose-plan[1]/section[1]/div[1]/div[2]/app-plans[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-plan[1]/div[1]/div[1]/div[2]/span[1]")
	private WebElement premium_plano_mensal_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-choose-plan[1]/section[1]/div[1]/div[2]/app-plans[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-plan[2]/div[1]/div[1]/div[1]")
	private WebElement premium_plano_anual_button;

	@FindBy(xpath = "//body/app-root[1]/app-checkout[1]/app-choose-plan[1]/section[1]/div[1]/div[2]/app-plans[1]/div[1]/div[1]/div[1]/div[2]/div[1]/app-coupon[1]/div[1]/div[1]/div[1]/a[1]")
	private WebElement premium_plano_adicionar_cupom_desconto_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-choose-plan[1]/section[1]/div[1]/div[2]/app-plans[1]/div[1]/div[1]/div[1]/div[2]/div[1]/app-coupon[1]/div[1]/div[1]/div[1]/div[1]/mat-form-field[1]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_adicionar_cupom_textarea;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-choose-plan[1]/section[1]/div[1]/div[2]/app-plans[1]/div[1]/div[1]/div[1]/div[2]/div[1]/app-coupon[1]/div[1]/div[1]/div[1]/div[2]/a[1]")
	private WebElement premium_plano_aplicar_cupom_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-choose-plan[1]/section[1]/div[1]/div[2]/app-plans[1]/div[1]/div[1]/div[2]/button[1]/span[1]")
	private WebElement premium_plano_continuar_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[1]/div[3]/mat-form-field[2]/div[1]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencherDados_numeroCartao;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[1]/div[3]/mat-form-field[3]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_nome;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[1]/div[3]/mat-form-field[4]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_validadeCartao;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[1]/div[3]/mat-form-field[5]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_codigoSegurancaCartao;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[1]/div[4]/div[2]/button[1]")
	private WebElement premium_plano_preencerDados_continuar_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/mat-form-field[1]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_inserir_cpf;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/mat-form-field[2]/div[1]/div[1]/div[1]/span[1]/label[1]/mat-label[1]")
	private WebElement premium_plano_preencerDados_inserir_nomeCompleto;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/mat-form-field[2]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_inserir_nomeCompleto_input;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/mat-form-field[3]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_inserir_dataNascimento;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/mat-form-field[4]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_inserir_email;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/mat-form-field[5]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_confirmar_email;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/mat-form-field[6]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_celularParaAlertas;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[2]/div[2]/div[2]/button[1]/span[1]")
	private WebElement premium_plano_preencerDados_proximo_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[3]/div[2]/div[1]/mat-form-field[1]/div[1]/div[1]/div[1]/span[1]/label[1]/mat-label[1]")
	private WebElement premium_plano_preencerDados_cep_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[3]/div[2]/div[1]/mat-form-field[1]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_cep_input;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[3]/div[2]/div[2]/mat-form-field[2]/div[1]/div[1]/div[1]/span[1]/label[1]/mat-label[1]")
	private WebElement premium_plano_preencerDados_numero_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[3]/div[2]/div[2]/mat-form-field[2]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_numero_input;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[3]/div[2]/div[2]/mat-form-field[3]/div[1]/div[1]/div[1]/span[1]/label[1]/mat-label[1]")
	private WebElement premium_plano_preencerDados_complemento_button;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[3]/div[2]/div[2]/mat-form-field[3]/div[1]/div[1]/div[1]/input[1]")
	private WebElement premium_plano_preencerDados_complemento_input;

	@FindBy(xpath = "/html[1]/body[1]/app-root[1]/app-checkout[1]/app-payment-data[1]/section[1]/div[2]/form[1]/div[3]/div[2]/div[3]/button[1]/span[1]")
	private WebElement premium_plano_preencerDados_iniciar_meuSerasaPremiun_button;

	public HirePlanPage(RemoteWebDriver driver) {
		super(driver);
	}

	public HirePlanPage clickContratarSerasaPremium(){
		waitForElement(premium_plano_preencerDados_iniciar_meuSerasaPremiun_button);
		this.premium_plano_preencerDados_iniciar_meuSerasaPremiun_button.click();
		return this;
	}

	public HirePlanPage endereco(String cep, String numero_endereco,String complemento){
		this.PremiumPlanoCep(cep);
		this.PremiumPlanoNumeroEndereco(numero_endereco);
		this.PremiumPlanoComplemento(complemento);
		return this;
	}

	public HirePlanPage quemEhVoce(String cpf,String nome,String dataNascimento,String email,String celular){
		this.PremiumPlanoInserirCpf(cpf);
		this.PremiumPlanoInserirNomeCompleto(nome);
		this.PremiumPlanoInserirDataNascimento(dataNascimento);
		this.PremiumPlanoInserirEmail(email);
		this.PremiumPlanoConfirmarEmail(email);
		this.PremiumPlanoCelularParaAlertas(celular);
		this.clickPremiumPlanoProximo();
		return this;
	}

	public HirePlanPage comoQuerPagar(String numero_cartao, String nome, String validade_cartao, String codigo_seguranca_cartao){
		this.PremiumPlanoInserirNumeroCartao(numero_cartao);
		this.PremiumPlanoInserirNome(nome);
		this.PremiumPlanoInserirValidadeCartao(validade_cartao);
		this.PremiumPlanoInserirCodigoSegurancaCartao(codigo_seguranca_cartao);
		this.clickPremiumPlanoContinuarCompra();
		return this;
	}

	public HirePlanPage adicionarCumponDesconto(String resposta, String cupom_desconto){
		if(resposta == "sim"){
			this.clickPremiumPlanoAddCupom();
			this.PremiumPlanoAddCupom(cupom_desconto);
			this.PremiumPlanoAplicarCupom();
			this.clickPremiumPlanoContinuar();
			return this;
		}else
		if(resposta == "não"){
			this.clickPremiumPlanoContinuar();
			return this;
		}
		return this;
	}

	public HirePlanPage escolhaUmPlano(String tipo_de_plano){
		if(tipo_de_plano == "mensal"){
			this.clickPremiumPlanoMensal();
			return this;
		} else
		if(tipo_de_plano == "anual"){
			this.clickPremiumPlanoAnual();
			return this;
		}
		return this;
	}

	public HirePlanPage PremiumPlanoComplemento(String complemento) {
		waitForElement(premium_plano_preencerDados_complemento_button);
		this.premium_plano_preencerDados_complemento_button.click();
		this.premium_plano_preencerDados_complemento_input.sendKeys(complemento);
		return this;
	}

	public HirePlanPage PremiumPlanoNumeroEndereco(String numero) {
		waitForElement(premium_plano_preencerDados_numero_button);
		this.premium_plano_preencerDados_numero_button.click();
		this.premium_plano_preencerDados_numero_input.sendKeys(numero);
		return this;
	}

	public HirePlanPage PremiumPlanoCep(String cep) {
		waitForElement(premium_plano_preencerDados_cep_button);
		this.premium_plano_preencerDados_cep_button.click();
		this.premium_plano_preencerDados_cep_input.sendKeys(cep);
		return this;
	}

	public HirePlanPage clickPremiumPlanoProximo() {
		waitForElement(premium_plano_preencerDados_proximo_button);
		this.premium_plano_preencerDados_proximo_button.click();
		return this;
	}

	public HirePlanPage PremiumPlanoCelularParaAlertas(String celular) {
		waitForElement(premium_plano_preencerDados_celularParaAlertas);
		this.premium_plano_preencerDados_celularParaAlertas.click();
		this.premium_plano_preencerDados_celularParaAlertas.sendKeys(celular);
		return this;
	}

	public HirePlanPage PremiumPlanoConfirmarEmail(String email) {
		waitForElement(premium_plano_preencerDados_confirmar_email);
		this.premium_plano_preencerDados_confirmar_email.click();
		this.premium_plano_preencerDados_confirmar_email.sendKeys(email);
		return this;
	}

	public HirePlanPage PremiumPlanoInserirEmail(String email) {
		waitForElement(premium_plano_preencerDados_inserir_email);
		this.premium_plano_preencerDados_inserir_email.click();
		this.premium_plano_preencerDados_inserir_email.sendKeys(email);
		return this;
	}

	public HirePlanPage PremiumPlanoInserirDataNascimento(String dataNacimento) {
		waitForElement(premium_plano_preencerDados_inserir_dataNascimento);
		this.premium_plano_preencerDados_inserir_dataNascimento.click();
		this.premium_plano_preencerDados_inserir_dataNascimento.sendKeys(dataNacimento);
		return this;
	}

	public HirePlanPage PremiumPlanoInserirNomeCompleto(String nome){
		waitForElement(premium_plano_preencerDados_inserir_nomeCompleto);
		this.premium_plano_preencerDados_inserir_nomeCompleto.click();
		this.premium_plano_preencerDados_inserir_nomeCompleto_input.sendKeys(nome);
		return this;
	}

	public HirePlanPage PremiumPlanoInserirCpf(String cpf) {
		waitForElement(premium_plano_preencerDados_inserir_cpf);
		this.premium_plano_preencerDados_inserir_cpf.click();
		this.premium_plano_preencerDados_inserir_cpf.sendKeys(cpf);
		return this;
	}

	public HirePlanPage clickPremiumPlanoContinuarCompra() {
		waitForElement(premium_plano_preencerDados_continuar_button);
		this.premium_plano_preencerDados_continuar_button.click();
		return this;
	}

	public HirePlanPage PremiumPlanoInserirCodigoSegurancaCartao(String codigo) {
		waitForElement(premium_plano_preencerDados_codigoSegurancaCartao);
		this.premium_plano_preencerDados_codigoSegurancaCartao.click();
		this.premium_plano_preencerDados_codigoSegurancaCartao.sendKeys(codigo);
		return this;
	}

	public HirePlanPage PremiumPlanoInserirValidadeCartao(String validade) {
		waitForElement(premium_plano_preencerDados_validadeCartao);
		this.premium_plano_preencerDados_validadeCartao.click();
		this.premium_plano_preencerDados_validadeCartao.sendKeys(validade);
		return this;
	}

	public HirePlanPage PremiumPlanoInserirNome(String nome) {
		waitForElement(premium_plano_preencerDados_nome);
		this.premium_plano_preencerDados_nome.click();
		this.premium_plano_preencerDados_nome.sendKeys(nome);
		return this;
	}

	public HirePlanPage PremiumPlanoInserirNumeroCartao(String numero_cartao) {
		waitForElement(premium_plano_preencherDados_numeroCartao);
		this.premium_plano_preencherDados_numeroCartao.click();
		this.premium_plano_preencherDados_numeroCartao.sendKeys(numero_cartao);
		return this;
	}

	public HirePlanPage clickPremiumPlanoContinuar() {
		waitForElement(premium_plano_continuar_button);
		this.premium_plano_continuar_button.click();
		return this;
	}

	public HirePlanPage PremiumPlanoAplicarCupom() {
		waitForElement(premium_plano_aplicar_cupom_button);
		this.premium_plano_aplicar_cupom_button.click();
		return this;
	}

	public HirePlanPage PremiumPlanoAddCupom(String cupom_desconto) {
		waitForElement(premium_plano_adicionar_cupom_textarea);
		this.premium_plano_adicionar_cupom_textarea.click();
		this.premium_plano_adicionar_cupom_textarea.sendKeys(cupom_desconto);
		return this;
	}

	public HirePlanPage clickPremiumPlanoAddCupom() {
		waitForElement(premium_plano_adicionar_cupom_desconto_button);
		this.premium_plano_adicionar_cupom_desconto_button.click();
		return this;
	}

	public HirePlanPage clickPremiumPlanoMensal() {
		waitForElement(premium_plano_mensal_button);
		this.premium_plano_mensal_button.click();
		return this;
	}

	public HirePlanPage clickPremiumPlanoAnual() {
		waitForElement(premium_plano_anual_button);
		this.premium_plano_anual_button.click();
		return this;
	}

}