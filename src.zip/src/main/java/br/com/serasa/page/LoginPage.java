package br.com.serasa.page;

import br.com.serasa.core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage {

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/header[1]/div[1]/div[3]/button[1]")
    private WebElement entrar_button;

    @FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/header[1]/div[2]/p[1]/a[1]")
    private WebElement criar_uma_conta_button;

    @FindBy(id = "cpf")
    private WebElement inserir_cpf_criacao_conta;

    @FindBy(id = "name")
    private WebElement inserir_nome_completo_criacao_conta;

    @FindBy(id = "birthDate")
    private WebElement inserir_data_nascimento_criacao_conta;

    @FindBy(id = "email")
    private WebElement inserir_email_criacao_conta;

    @FindBy(id = "password")
    private WebElement inserir_senha_criacao_conta;

    @FindBy(xpath = "/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/form[1]/div[8]/label[1]/span[1]")
    private WebElement aceitar_termos_criacao_conta;

    @FindBy(xpath = "/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/form[1]/div[9]/input[1]")
    private WebElement criar_conta_gratis_button;

    @FindBy(id = "f-cpf")
    private WebElement inserir_cpf_login;

    @FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[2]/button[1]")
    private WebElement continuar_login_button;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[5]/div[1]/a[1]")
    private WebElement consultar_cpf_button;

    @FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/input[1]")
    private WebElement inserir_cpf_login_consulta_cpf;

    @FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/header[1]/div[1]/a[1]/img[1]")
    private WebElement homePage;

    public LoginPage(RemoteWebDriver driver) {
        super(driver);
    }

    public LoginPage clickEntrarbutton() {
        waitForElement(entrar_button);
        this.entrar_button.click();
        return this;
    }

    public LoginPage clickCriarUmaContaButton() {
        waitForElement(criar_uma_conta_button);
        this.criar_uma_conta_button.click();
        return this;
    }

    public LoginPage inserirCpfCriacaoConta(String cpf) {
        waitForElement(inserir_cpf_criacao_conta);
        this.inserir_cpf_criacao_conta.click();
        this.inserir_cpf_criacao_conta.sendKeys(cpf);
        return this;
    }

    public LoginPage inserirNomeCriacaoConta(String nome) {
        waitForElement(inserir_nome_completo_criacao_conta);
        this.inserir_nome_completo_criacao_conta.click();
        this.inserir_nome_completo_criacao_conta.sendKeys(nome);
        return this;
    }

    public LoginPage inserirDataNascimentoCriacaoConta(String dataNascimento) {
        waitForElement(inserir_data_nascimento_criacao_conta);
        this.inserir_data_nascimento_criacao_conta.click();
        this.inserir_data_nascimento_criacao_conta.sendKeys(dataNascimento);
        return this;
    }

    public LoginPage inserirEmailCriacaoConta(String email) {
        waitForElement(inserir_email_criacao_conta);
        this.inserir_email_criacao_conta.click();
        this.inserir_email_criacao_conta.sendKeys(email);
        return this;
    }

    public LoginPage inserirSenhaCriacaoConta(String senha) {
        waitForElement(inserir_senha_criacao_conta);
        this.inserir_senha_criacao_conta.click();
        this.inserir_senha_criacao_conta.sendKeys(senha);
        return this;
    }

    public LoginPage aceitarTermosCriacaoConta() {
        waitForElement(aceitar_termos_criacao_conta);
        this.aceitar_termos_criacao_conta.click();
        return this;
    }

    public LoginPage clickCriarContaGratisButton() {
        waitForElement(criar_conta_gratis_button);
        this.criar_conta_gratis_button.click();
        return this;
    }

    public LoginPage inserirCpfLogin(String cpf) {
        waitForElement(inserir_cpf_login);
        this.inserir_cpf_login.click();
        this.inserir_cpf_login.sendKeys(cpf);
        return this;
    }

    public LoginPage continuarLoginButton() {
        waitForElement(continuar_login_button);
        this.continuar_login_button.click();
        return this;
    }

    public LoginPage consultarCpfButton() {
        waitForElement(consultar_cpf_button);
        this.consultar_cpf_button.click();
        return this;
    }

    public LoginPage inserirCpfConsultaLogin(String cpf) {
        waitForElement(inserir_cpf_login_consulta_cpf);
        this.inserir_cpf_login_consulta_cpf.click();
        this.inserir_cpf_login_consulta_cpf.sendKeys(cpf);
        return this;
    }

    public LoginPage goBackHomePage() {
        waitForElement(homePage);
        this.homePage.click();
        return this;
    }

}