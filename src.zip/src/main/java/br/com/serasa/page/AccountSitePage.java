package br.com.serasa.page;

import br.com.serasa.core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class AccountSitePage extends BasePage {

	@FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/header[1]/div[1]/div[3]/button[1]")
	private WebElement entrar_button;

	@FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/header[1]/div[2]/p[1]/a[1]")
	private WebElement criar_uma_conta_button;

	@FindBy(id = "cpf")
	private WebElement inserir_cpf_criacao_conta;

	@FindBy(id = "name")
	private WebElement inserir_nome_completo_criacao_conta;

	@FindBy(id = "birthDate")
	private WebElement inserir_data_nascimento_criacao_conta;

	@FindBy(id = "email")
	private WebElement inserir_email_criacao_conta;

	@FindBy(id = "password")
	private WebElement inserir_senha_criacao_conta;

	@FindBy(xpath = "/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/form[1]/div[8]/label[1]/span[1]")
	private WebElement aceitar_termos_criacao_conta;

	@FindBy(xpath = "/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/form[1]/div[9]/input[1]")
	private WebElement criar_conta_gratis_button;

	@FindBy(id = "f-cpf")
	private WebElement inserir_cpf_login;

	@FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[2]/button[1]")
	private WebElement continuar_login_button;

	@FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/input[1]")
	private WebElement inserir_cpf_login_consulta_cpf;

	@FindBy(xpath = "/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/header[1]/div[1]/a[1]/img[1]")
	private WebElement homePage;

	public AccountSitePage(RemoteWebDriver driver) {
		super(driver);
	}

	public AccountSitePage clickEntrarbutton() {
		waitForElement(entrar_button);
		this.entrar_button.click();
		return this;
	}

	public AccountSitePage clickCriarUmaContaButton() {
		waitForElement(criar_uma_conta_button);
		this.criar_uma_conta_button.click();
		return this;
	}

	public AccountSitePage inserirCpfCriacaoConta(String cpf) {
		waitForElement(inserir_cpf_criacao_conta);
		this.inserir_cpf_criacao_conta.click();
		this.inserir_cpf_criacao_conta.sendKeys(cpf);
		return this;
	}

	public AccountSitePage inserirNomeCriacaoConta(String nome) {
		waitForElement(inserir_nome_completo_criacao_conta);
		this.inserir_nome_completo_criacao_conta.click();
		this.inserir_nome_completo_criacao_conta.sendKeys(nome);
		return this;
	}

	public AccountSitePage inserirDataNascimentoCriacaoConta(String dataNascimento) {
		waitForElement(inserir_data_nascimento_criacao_conta);
		this.inserir_data_nascimento_criacao_conta.click();
		this.inserir_data_nascimento_criacao_conta.sendKeys(dataNascimento);
		return this;
	}

	public AccountSitePage inserirEmailCriacaoConta(String email) {
		waitForElement(inserir_email_criacao_conta);
		this.inserir_email_criacao_conta.click();
		this.inserir_email_criacao_conta.sendKeys(email);
		return this;
	}

	public AccountSitePage inserirSenhaCriacaoConta(String senha) {
		waitForElement(inserir_senha_criacao_conta);
		this.inserir_senha_criacao_conta.click();
		this.inserir_senha_criacao_conta.sendKeys(senha);
		return this;
	}

	public AccountSitePage aceitarTermosCriacaoConta() {
		waitForElement(aceitar_termos_criacao_conta);
		this.aceitar_termos_criacao_conta.click();
		return this;
	}

	public AccountSitePage clickCriarContaGratisButton() {
		waitForElement(criar_conta_gratis_button);
		this.criar_conta_gratis_button.click();
		return this;
	}

	public AccountSitePage inserirCpfLogin(String cpf) {
		waitForElement(inserir_cpf_login);
		this.inserir_cpf_login.click();
		this.inserir_cpf_login.sendKeys(cpf);
		return this;
	}

	public AccountSitePage continuarLoginButton() {
		waitForElement(continuar_login_button);
		this.continuar_login_button.click();
		return this;
	}

	public AccountSitePage inserirCpfConsultaLogin(String cpf) {
		waitForElement(inserir_cpf_login_consulta_cpf);
		this.inserir_cpf_login_consulta_cpf.click();
		this.inserir_cpf_login_consulta_cpf.sendKeys(cpf);
		return this;
	}

	public AccountSitePage goBackHomePage() {
		waitForElement(homePage);
		this.homePage.click();
		return this;
	}
}