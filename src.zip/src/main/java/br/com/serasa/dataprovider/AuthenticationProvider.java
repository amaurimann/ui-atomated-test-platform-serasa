package br.com.serasa.dataprovider;

import br.com.serasa.model.User;
import org.testng.annotations.DataProvider;

public class AuthenticationProvider {

    @DataProvider(name = "authenticateUserProvider")
    public Object[][] getAuthentication() {
        User user1 = User.builder().email("amaurimoraismann@gmail.com").password("Minhasenha123").build();
        return new Object[][]{
                {
                        user1
                }
        };
    }
}