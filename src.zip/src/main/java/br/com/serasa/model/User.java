package br.com.serasa.model;

import lombok.*;

@AllArgsConstructor
@Builder
@Data
@NoArgsConstructor
@Getter
public class User {
    private String email, password;
}