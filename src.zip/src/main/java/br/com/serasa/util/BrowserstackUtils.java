package br.com.serasa.util;

import br.com.serasa.core.BrowserStackFactory;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.SessionId;

/**
 * @author amauri.mann
 */
public class BrowserstackUtils extends BrowserStackFactory {

    public static void setTestStatus(String status, String message) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("browserstack_executor: {\"action\": \"setSessionStatus\", \"arguments\": {\"status\": \"" + status + "\", \"reason\": \"" + message + "\"}}");
    }

    public static void setTestName(String name) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("browserstack_executor: {\"action\": \"setSessionName\", \"arguments\": {\"name\": \"" + name + "\"}}");
    }

    public SessionId getSessionId() {
        SessionId value = driver.getSessionId();
        return value;
    }
}