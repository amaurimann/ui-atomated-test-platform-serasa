package br.com.serasa.core;

/**
 * @author Amauri.mann
 */
public class Constants {

//    public static final String USER_NAME = "amaurimoraismann_qL3hsa";
//    public static final String ACCESS_KEY = "v81FXLTPVGqPrG8sJxuM";
    public static final String USER_NAME = "amaurimoraismann_1LrN4P";
    public static final String ACCESS_KEY = "LmVstxiPWLWiD6KkbgfD";
    public static final String BS_C0NNECTION = "https://" + USER_NAME + ":" + ACCESS_KEY
            + "@hub-cloud.browserstack.com/wd/hub";
}
