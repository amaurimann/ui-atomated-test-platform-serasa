package br.com.serasa.business;

import br.com.serasa.core.BasePage;
import br.com.serasa.model.User;
import br.com.serasa.page.LoginPage;
import br.com.serasa.page.AccountSitePage;
import org.openqa.selenium.remote.RemoteWebDriver;

public class LoginRules extends BasePage {
    private LoginPage loginPage;

	private AccountSitePage accountSitePage;

    public LoginRules(RemoteWebDriver driver) {
        super(driver);
        loginPage = new LoginPage(driver);
    }

    public AccountSitePage createAccount(String cpf, String nome, String dataNascimento, String email, String senha) {
        accountSitePage = new AccountSitePage(driver);
        return accountSitePage
                .clickEntrarbutton()
                .clickCriarUmaContaButton()
                .inserirCpfCriacaoConta(cpf)
                .inserirNomeCriacaoConta(nome)
                .inserirDataNascimentoCriacaoConta(dataNascimento)
                .inserirEmailCriacaoConta(email)
                .inserirSenhaCriacaoConta(senha)
                .aceitarTermosCriacaoConta()
                .clickCriarContaGratisButton();
    }
    public LoginPage loginSite(String cpf_login) {
        loginPage = new LoginPage(driver);
        return loginPage.clickEntrarbutton()
                .inserirCpfLogin(cpf_login)
                .continuarLoginButton();
    }

}