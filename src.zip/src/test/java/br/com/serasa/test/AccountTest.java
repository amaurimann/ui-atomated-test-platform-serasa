package br.com.serasa.test;

import br.com.serasa.business.LoginRules;
import br.com.serasa.core.BaseTest;
import br.com.serasa.env.EnvironmentActualLoader;
import br.com.serasa.env.PropertieLoader;
import br.com.serasa.model.User;
import br.com.serasa.page.LoginPage;
import br.com.serasa.page.NavigationPage;
import br.com.serasa.page.AccountSitePage;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import org.openqa.selenium.JavascriptExecutor;

import static org.testng.Assert.*;
import static org.testng.Assert.assertTrue;

/**
 * @author Amauri.mann
 *  * OBS: during the ui automated test occours a error in login and create account, blockin the success of login and creation of account
 *  * probably the system identify the robot tryng to access the platform and block that action.
 * Scenario test case
 *  create account
 *  login in site
 */

public class AccountTest extends BaseTest {
	// V1 : CRIAR CENARIOS AUTOMATIZADOS QUE SIMULEM CONTRAÇÃO DE PLANOS E CONSULTAS COM USUÁRIOS ESTATICOS E PRIVADOS
	// PÓS DESENVOLVIMENTO V1 : ADICIONAR METODOS PARA GERAR VALORES RANDOMICOS DE CPF, NOME, ETC ....

	LoginRules loginRules = new LoginRules(driver);

	private String cpf = "53811326031";
	private String nome = "darth vader";
	private String dataNascimento = "25081993";
	private String email = "darthvader@gmail.com";
	private String senha = "Espada4110@%";

	@Test(description = "Successfully create your account", groups = {"create-account.test"})
	public void A_createAccount() {
		loginRules.createAccount(cpf, nome, dataNascimento, email, senha);
	}

	@Test(description = "Successfully login your account", groups = {"login-site.test"})
	public void B_loginSite() throws InterruptedException{
		loginRules.loginSite(cpf);
	}
}




