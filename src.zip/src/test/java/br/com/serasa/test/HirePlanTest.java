package br.com.serasa.test;

import br.com.serasa.business.LoginRules;
import br.com.serasa.core.BaseTest;
import br.com.serasa.env.EnvironmentActualLoader;
import br.com.serasa.env.PropertieLoader;
import br.com.serasa.model.User;
import br.com.serasa.page.LoginPage;
import br.com.serasa.page.NavigationPage;
import br.com.serasa.page.AccountSitePage;
import br.com.serasa.page.HirePlanPage;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.openqa.selenium.JavascriptExecutor;
import static org.testng.Assert.*;
import static org.testng.Assert.assertTrue;

/**
 * @author Amauri.mann
 * Scenario tests
 * Hire Serasa Premiun mounthly plan whit discount
 * Hire Serasa Premiun annual plan whit no discount*/

public class HirePlanTest extends BaseTest {
	// V1 : CRIAR CENARIOS AUTOMATIZADOS QUE SIMULEM CONTRAÇÃO DE PLANOS E CONSULTAS COM USUÁRIOS ESTATICOS E PRIVADOS
	// PÓS DESENVOLVIMENTO V1 : ADICIONAR METODOS PARA GERAR VALORES RANDOMICOS DE CPF, NOME, ETC ....

	private String cpf_login = "53811326031";
	private String cpf = "53811326031";
	private String nome = "Darth Vader";
	private String dataNascimento = "25081993";
	private String email = "darthvader@gmail.com";
	private String cupom_desconto = "123456";
	private String numero_cartao = "5234214789661234";
	private String validade_cartao = "0626";
	private String codigo_seguranca_cartao = "123";
	private String celular = "51988776655";
	private String cep = "91450147";
	private String numero_endereco = "700";
	private String complemento = "apto 1001 torre A";

	@Test(description = "Successfully Hire a Premium Plan whit monthly payment and discount", groups = {"hire-premium.test"})
	public void F_hirePremiumPlanMounthlyWhitDiscount() throws InterruptedException {
		NavigationPage navigationPage = new NavigationPage(driver);
		HirePlanPage hirePlanPage = new HirePlanPage(driver);

		navigationPage.clickOqueVocePrecisaButton();
		navigationPage.clickSubMenuPremium();
		navigationPage.clickPremiumConhecaNossosPlanos();
		driver.switchTo().window((String) driver.getWindowHandles().toArray()[1]);
		hirePlanPage.escolhaUmPlano("mensal");
		hirePlanPage.adicionarCumponDesconto("sim", "999");
		hirePlanPage.comoQuerPagar(numero_cartao, nome, validade_cartao, codigo_seguranca_cartao);
		hirePlanPage.quemEhVoce(cpf, nome, dataNascimento, email, celular);
		hirePlanPage.endereco(cep, numero_endereco, complemento);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		hirePlanPage.clickContratarSerasaPremium();
	}

	@Test(description = "Successfully Hire a Premium Plan whit annual payment and no discount", groups = {"hire-premium.test"})
	public void G_hirePremiumPlanAnnualWhitNoDiscount() throws InterruptedException {
		NavigationPage navigationPage = new NavigationPage(driver);
		HirePlanPage hirePlanPage = new HirePlanPage(driver);

		navigationPage.clickOqueVocePrecisaButton();
		navigationPage.clickSubMenuPremium();
		navigationPage.clickPremiumConhecaNossosPlanos();
		driver.switchTo().window((String) driver.getWindowHandles().toArray()[1]);
		hirePlanPage.escolhaUmPlano("anual");
		hirePlanPage.adicionarCumponDesconto("não", "cupomDesconto");
		hirePlanPage.comoQuerPagar(numero_cartao, nome, validade_cartao, codigo_seguranca_cartao);
		hirePlanPage.quemEhVoce(cpf, nome, dataNascimento, email, celular);
		hirePlanPage.endereco(cep, numero_endereco, complemento);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		hirePlanPage.clickContratarSerasaPremium();
	}
}






