package br.com.serasa.test;

import br.com.serasa.business.LoginRules;
import br.com.serasa.core.BaseTest;
import br.com.serasa.env.EnvironmentActualLoader;
import br.com.serasa.env.PropertieLoader;
import br.com.serasa.model.User;
import br.com.serasa.page.LoginPage;
import br.com.serasa.page.NavigationPage;
import br.com.serasa.page.AccountSitePage;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import org.openqa.selenium.JavascriptExecutor;

import static org.testng.Assert.*;
import static org.testng.Assert.assertTrue;

/**
 * @author Amauri.mann
 * Scenario tests
 * Access Consultar Cpf by home page button
 * Access Ecred by home page -> O que você precisa modal
 * Acces Limpar meu nome -> O que você precisa modal*/

public class NavigationTest extends BaseTest {
	// V1 : CRIAR CENARIOS AUTOMATIZADOS QUE SIMULEM CONTRAÇÃO DE PLANOS E CONSULTAS COM USUÁRIOS ESTATICOS E PRIVADOS
	// PÓS DESENVOLVIMENTO V1 : ADICIONAR METODOS PARA GERAR VALORES RANDOMICOS DE CPF, NOME, ETC ....

	private String cpf_login = "53811326031";// OBS: DELETE THIS SENSIVITY INFORMATION

	@Test(description = "Successfully consult social security", groups = {"consult-cpf.test"})
	public void C_consultCpf() throws InterruptedException {
		AccountSitePage accountSitepage = new AccountSitePage(driver);
		NavigationPage navigationPage = new NavigationPage(driver);

		navigationPage.homeConsultarCpfButton();
		accountSitepage.inserirCpfConsultaLogin(cpf_login);
		accountSitepage.continuarLoginButton();
	}

	@Test(description = "Successfully navigation", groups = {"navigation-ecred.test"})
	public void D_accessEcred() throws InterruptedException {
		NavigationPage navigationPage = new NavigationPage(driver);
		AccountSitePage accountSitePage = new AccountSitePage(driver);

		navigationPage.clickOqueVocePrecisaButton();
		navigationPage.clickSubMenuEcred();
		navigationPage.clickEcredSimuleGratis();
		accountSitePage.inserirCpfConsultaLogin(cpf_login);
		accountSitePage.continuarLoginButton();
	}

	@Test(description = "Successfully navigation", groups = {"navigation-limpaNome.test"})
	public void E_accessLimpaNome() throws InterruptedException {
		NavigationPage navigationPage = new NavigationPage(driver);

		navigationPage.clickOqueVocePrecisaButton();
		navigationPage.clickSubMenuLimpaNome();
	}
}






